import bpy, bmesh
import math
from mathutils import Vector
from mathutils.interpolate import poly_3d_calc


def getRayCastDirections():
    #Using an IsoSphere vertex to get the raycast directions for each point
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2, radius=1, enter_editmode=False, location=(0, 0, 0))
    Sphere = bpy.context.object
    Sphere.name = "RaycastSphere"
    
    raycastDirs = [vert.co for vert in Sphere.data.vertices]
    #Vector.normalize()
    #we are going to use the verts.co as raycast direction for 360 coverage
    bpy.data.objects.remove(Sphere, do_unlink=True)
    return raycastDirs
    #RCDirs = getRayCastDirections()
    
def raycastAllDirection(obj, vetPos, rcDirs, rcLength):
    # Cast  rays
    ray_origin = vetPos
    valueSignDist = 99999999
    for dir in rcDirs:
        success, location, normal, poly_index = obj.ray_cast(ray_origin, dir, distance = rcLength)
        if(success):
            value = (location-vetPos).length
            value = math.copysign(value,-Vector.dot(dir, normal))
            if(abs(value)<abs(valueSignDist)):
                valueSignDist = value
    return valueSignDist

def saveSDasVertexColor(obj, signDists):
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    
    mesh = obj.data
    bpy.ops.object.mode_set(mode = 'VERTEX_PAINT')
    for vertindex in range(len(signDists)):
        for polygon in mesh.polygons:
            for i, index in enumerate(polygon.vertices):
                if vertindex == index:
                    loop_index = polygon.loop_indices[i]
                    r = signDists[vertindex]
                    mesh.vertex_colors.active.data[loop_index].color = [r,r,r,1.0]
    bpy.ops.object.mode_set(mode = 'OBJECT')

def BakeAOUsingWrapMesh():
    context = bpy.context
    #sel = bpy.context.selected_objects
    #act = bpy.context.active_object

    obj_original = bpy.context.view_layer.objects.active
    # make sure in object mode
    bpy.ops.object.mode_set(mode = 'OBJECT')

    if not obj_original:
        print("Nothing Active!!")

    #Select Target mesh
    obj_original.select_set(True)

    WrapMeshName = obj_original.name+"_WrapMesh"
    try:
        obj_warpmesh = bpy.data.objects[WrapMeshName]
    except:
        raise TypeError("Active does not have a wrapmesh!!")

    #get all vertex position
    vetPoss = [vert.co for vert in obj_original.data.vertices]

    #get raycast directions for each vert
    rcDirs = getRayCastDirections()

    #raycastlength
    rcLength = max(max(obj_warpmesh.dimensions.x, obj_warpmesh.dimensions.y),obj_warpmesh.dimensions.z)
    
    #depsgraph = context.evaluated_depsgraph_get()
    #depsgraph.update()  # just in case
    #obj = obj_warpmesh.evaluated_get(depsgraph)
    obj_warpmesh.hide_viewport = False

    #get Sign distance for All vert using raycast
    signDist = []
    for i in range(len(vetPoss)):
        signDist.append(raycastAllDirection(obj_warpmesh, vetPoss[i], rcDirs, rcLength))

    obj_warpmesh.hide_viewport = True
    maxDist = max(signDist)
    minDist = min(signDist)

    for i in range(len(vetPoss)):
        signDist[i] = (signDist[i]-minDist)/(maxDist-minDist)
        signDist[i] = signDist[i]*signDist[i]
        
    saveSDasVertexColor(obj_original, signDist)

if __name__ == "__main__":
    BakeAOUsingWrapMesh()      

"""
#Apply transforms
bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

bpy.ops.object.editmode_toggle()
bpy.ops.mesh.select_all(action='SELECT')
me = obj_original.data
bm = bmesh.from_edit_mesh(me)
bm.verts.ensure_lookup_table()#update internal index table
#verts = [v.co for v in bm.verts]
vert0 = bm.verts[0]

print(vert0.co)


bpy.ops.object.editmode_toggle()
"""
"""
depsgraph = context.evaluated_depsgraph_get()
depsgraph.update()  # just in case
#obj = bpy.data.objects['Cube'].evaluated_get(depsgraph)

# Cast a ray
ray_origin = Vector((0, 0, 7))
ray_direction = Vector((0, 0, 10))
for i in range(100000):
    success, location, normal, poly_index = obj_original.ray_cast(ray_origin, ray_direction)



print(success)
print(location)
print(normal)
print(poly_index)
"""
"""
bpy.ops.object.editmode_toggle()
    bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.delete(type='ONLY_FACE')
    me = Sphere.data
    bm = bmesh.from_edit_mesh(me)
    #update internal index table
    bm.verts.ensure_lookup_table()
"""

"""
#print(RCDirs[0:3])
#def rayCastObjectforPoint
mesh = bpy.context.active_object.data

currentVertIndex = 10
bpy.ops.object.mode_set(mode = 'VERTEX_PAINT')
for vertindex in range(len(mesh.vertices)):
    for polygon in mesh.polygons:
        for i, index in enumerate(polygon.vertices):
            if vertindex == index:
                loop_index = polygon.loop_indices[i]
                r = vertindex/len(mesh.vertices)-0.5
                mesh.vertex_colors.active.data[loop_index].color = [r,0,0,1.0]
bpy.ops.object.mode_set(mode = 'EDIT')
"""

