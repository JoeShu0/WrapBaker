bl_info = {
    "name": "Wrap Normal AO Baker",
    "blender": (3, 20, 0),
    "category": "Object",
}


if "bpy" in locals():
    import importlib
    importlib.reload(WrapNormal)
    importlib.reload(WarpAO)
else:
    import bpy
    from . import WrapNormal 
    from . import WarpAO

class BakeWarpNomral(bpy.types.Operator):
    """Generate Wrap mesh for selected mesh and transfer normal to mesh"""      # Use this as a tooltip for menu items and buttons.
    bl_idname = "object.bake_wrap_normal"        # Unique identifier for buttons and menu items to reference.
    bl_label = "Bake Wrap Normal"         # Display name in the interface.
    bl_options = {'REGISTER', 'UNDO'}  # Enable undo for the operator.

    def execute(self, context):        # execute() is called when running the operator.
        # The original script
        WrapNormal.WrapSelectedObjectTranferNormal()
        return {'FINISHED'}            # Lets Blender know the operator finished successfully.

class BakeWarpAO(bpy.types.Operator):
    """Bake Wrap AO to selected mesh using wrap mesh"""      # Use this as a tooltip for menu items and buttons.
    bl_idname = "object.bake_wrap_ao"        # Unique identifier for buttons and menu items to reference.
    bl_label = "Bake Wrap AO"         # Display name in the interface.
    bl_options = {'REGISTER', 'UNDO'}  # Enable undo for the operator.
    def execute(self, context):        # execute() is called when running the operator.
        # The original script
        WarpAO.BakeAOUsingWrapMesh()
        return {'FINISHED'}            # Lets Blender know the operator finished successfully.

#Object Menu
class WrapBakerMenu(bpy.types.Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "Wrap Normal AO Baker"
    bl_idname = "object.wrap_baker"

    def draw(self, context):
        layout = self.layout

        row = layout.row()
        row.operator("object.bake_wrap_normal")

        row = layout.row()
        row.operator("object.bake_wrap_ao")

#3D视图右侧工具面板
class WrapBakerPanel(bpy.types.Panel):
    bl_idname      = "WrapBaker_panel"
    bl_label       = "WrapBaker"
    bl_category    = "WrapBaker"
    bl_space_type  = "VIEW_3D"
    bl_region_type = "UI"
    bl_context     = "objectmode"

    def draw(self, context):
        layout = self.layout
        obj = context.object
        
        #Wrap 法线烘焙，阻塞
        normal_bake_row= layout.row()
        normal_bake_row.operator("object.bake_wrap_normal",text="Bake Selected Wrap Normal")
        AO_bake_row= layout.row()
        AO_bake_row.operator("object.bake_wrap_ao",text="Bake Selected Wrap SDF AO")

        """
        #Wrap AO烘焙，阻塞，有进度条
        if obj.progress: 
            progress_bar = layout.row()
            progress_bar.prop(bpy.context.object,"aobake_progress")
            progress_lbl = layout.row()
            progress_lbl.active = False
            progress_lbl.label(text=bpy.context.object.aobake_progress_label)
        else:
            ope = layout.row()
            ope.operator("example.modal_operator",text="Run Modal Operator")
        return """

#Object 下拉菜单
def menu_func(self, context):
    self.layout.label(text="Wrap Baker")
    self.layout.operator(BakeWarpNomral.bl_idname)
    self.layout.operator(BakeWarpAO.bl_idname)
    #self.layout.menu(WrapBakerMenu.bl_idname)

def register():
    #
    #bpy.types.Object.aobake_progress = bpy.props.FloatProperty( name="AO Bake Progress", subtype="PERCENTAGE",soft_min=0, soft_max=100, precision=0,)
    #bpy.types.Object.aobake_progress_label = bpy.props.StringProperty()

    bpy.utils.register_class(BakeWarpNomral)
    bpy.utils.register_class(BakeWarpAO)
    bpy.types.VIEW3D_MT_object.append(menu_func)
    #bpy.types.VIEW3D_MT_object.append(menu_func)  # Adds the new operator to an existing menu.
    #bpy.utils.register_class(WrapBakerMenu)
    bpy.utils.register_class(WrapBakerPanel)


def unregister():
    bpy.utils.unregister_class(BakeWarpNomral)
    bpy.utils.unregister_class(BakeWarpAO)
    bpy.types.VIEW3D_MT_object.remove(menu_func)
    #bpy.utils.unregister_class(WrapBakerMenu)
    bpy.utils.unregister_class(WrapBakerPanel)


# This allows you to run the script directly from Blender's Text editor
# to test the add-on without having to install it.
if __name__ == "__main__":
    register()